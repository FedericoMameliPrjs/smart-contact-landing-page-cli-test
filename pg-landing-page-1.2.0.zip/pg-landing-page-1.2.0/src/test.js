const utils = require('./utils/utils');

const options = utils.getArgvOptions();
console.log(options);

